/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Anderson
 */
public class cronogramaEstudos {
    private int ID_Cronograma_Estudos;
    private int ID_Usuario;
    private String Segunda1;
    private String Segunda2;
    private String Segunda3;
    private String Segunda4;
    private String Segunda5;
    private String Segunda6;
    private String Segunda7;
    private String Segunda8;
    
    private String Terca1;
    private String Terca2;
    private String Terca3;
    private String Terca4;
    private String Terca5;
    private String Terca6;
    private String Terca7;
    private String Terca8;
    
    private String Quarta1;
    private String Quarta2;
    private String Quarta3;
    private String Quarta4;
    private String Quarta5;
    private String Quarta6;
    private String Quarta7;
    private String Quarta8;
    
    private String Quinta1;
    private String Quinta2;
    private String Quinta3;
    private String Quinta4;
    private String Quinta5;
    private String Quinta6;
    private String Quinta7;
    private String Quinta8;
    
    private String Sexta1;
    private String Sexta2;
    private String Sexta3;
    private String Sexta4;
    private String Sexta5;
    private String Sexta6;
    private String Sexta7;
    private String Sexta8;
    
    private String Sabado1;
    private String Sabado2;
    private String Sabado3;
    private String Sabado4;
    private String Sabado5;
    private String Sabado6;
    private String Sabado7;
    private String Sabado8;
    
    private String Domingo1;
    private String Domingo2;
    private String Domingo3;
    private String Domingo4;
    private String Domingo5;
    private String Domingo6;
    private String Domingo7;
    private String Domingo8;

    public String getSegunda1() {
        return Segunda1;
    }

    public int getID_Cronograma_Estudos() {
        return ID_Cronograma_Estudos;
    }

    public void setID_Cronograma_Estudos(int ID_Cronograma_Estudos) {
        this.ID_Cronograma_Estudos = ID_Cronograma_Estudos;
    }

    public int getID_Usuario() {
        return ID_Usuario;
    }

    public void setID_Usuario(int ID_Usuario) {
        this.ID_Usuario = ID_Usuario;
    }

    public void setSegunda1(String Segunda1) {
        this.Segunda1 = Segunda1;
    }

    public String getSegunda2() {
        return Segunda2;
    }

    public void setSegunda2(String Segunda2) {
        this.Segunda2 = Segunda2;
    }

    public String getSegunda3() {
        return Segunda3;
    }

    public void setSegunda3(String Segunda3) {
        this.Segunda3 = Segunda3;
    }

    public String getSegunda4() {
        return Segunda4;
    }

    public void setSegunda4(String Segunda4) {
        this.Segunda4 = Segunda4;
    }

    public String getSegunda5() {
        return Segunda5;
    }

    public void setSegunda5(String Segunda5) {
        this.Segunda5 = Segunda5;
    }

    public String getSegunda6() {
        return Segunda6;
    }

    public void setSegunda6(String Segunda6) {
        this.Segunda6 = Segunda6;
    }

    public String getSegunda7() {
        return Segunda7;
    }

    public void setSegunda7(String Segunda7) {
        this.Segunda7 = Segunda7;
    }

    public String getSegunda8() {
        return Segunda8;
    }

    public void setSegunda8(String Segunda8) {
        this.Segunda8 = Segunda8;
    }

    public String getTerca1() {
        return Terca1;
    }

    public void setTerca1(String Terca1) {
        this.Terca1 = Terca1;
    }

    public String getTerca2() {
        return Terca2;
    }

    public void setTerca2(String Terca2) {
        this.Terca2 = Terca2;
    }

    public String getTerca3() {
        return Terca3;
    }

    public void setTerca3(String Terca3) {
        this.Terca3 = Terca3;
    }

    public String getTerca4() {
        return Terca4;
    }

    public void setTerca4(String Terca4) {
        this.Terca4 = Terca4;
    }

    public String getTerca5() {
        return Terca5;
    }

    public void setTerca5(String Terca5) {
        this.Terca5 = Terca5;
    }

    public String getTerca6() {
        return Terca6;
    }

    public void setTerca6(String Terca6) {
        this.Terca6 = Terca6;
    }

    public String getTerca7() {
        return Terca7;
    }

    public void setTerca7(String Terca7) {
        this.Terca7 = Terca7;
    }

    public String getTerca8() {
        return Terca8;
    }

    public void setTerca8(String Terca8) {
        this.Terca8 = Terca8;
    }

    public String getQuarta1() {
        return Quarta1;
    }

    public void setQuarta1(String Quarta1) {
        this.Quarta1 = Quarta1;
    }

    public String getQuarta2() {
        return Quarta2;
    }

    public void setQuarta2(String Quarta2) {
        this.Quarta2 = Quarta2;
    }

    public String getQuarta3() {
        return Quarta3;
    }

    public void setQuarta3(String Quarta3) {
        this.Quarta3 = Quarta3;
    }

    public String getQuarta4() {
        return Quarta4;
    }

    public void setQuarta4(String Quarta4) {
        this.Quarta4 = Quarta4;
    }

    public String getQuarta5() {
        return Quarta5;
    }

    public void setQuarta5(String Quarta5) {
        this.Quarta5 = Quarta5;
    }

    public String getQuarta6() {
        return Quarta6;
    }

    public void setQuarta6(String Quarta6) {
        this.Quarta6 = Quarta6;
    }

    public String getQuarta7() {
        return Quarta7;
    }

    public void setQuarta7(String Quarta7) {
        this.Quarta7 = Quarta7;
    }

    public String getQuarta8() {
        return Quarta8;
    }

    public void setQuarta8(String Quarta8) {
        this.Quarta8 = Quarta8;
    }

    public String getQuinta1() {
        return Quinta1;
    }

    public void setQuinta1(String Quinta1) {
        this.Quinta1 = Quinta1;
    }

    public String getQuinta2() {
        return Quinta2;
    }

    public void setQuinta2(String Quinta2) {
        this.Quinta2 = Quinta2;
    }

    public String getQuinta3() {
        return Quinta3;
    }

    public void setQuinta3(String Quinta3) {
        this.Quinta3 = Quinta3;
    }

    public String getQuinta4() {
        return Quinta4;
    }

    public void setQuinta4(String Quinta4) {
        this.Quinta4 = Quinta4;
    }

    public String getQuinta5() {
        return Quinta5;
    }

    public void setQuinta5(String Quinta5) {
        this.Quinta5 = Quinta5;
    }

    public String getQuinta6() {
        return Quinta6;
    }

    public void setQuinta6(String Quinta6) {
        this.Quinta6 = Quinta6;
    }

    public String getQuinta7() {
        return Quinta7;
    }

    public void setQuinta7(String Quinta7) {
        this.Quinta7 = Quinta7;
    }

    public String getQuinta8() {
        return Quinta8;
    }

    public void setQuinta8(String Quinta8) {
        this.Quinta8 = Quinta8;
    }

    public String getSexta1() {
        return Sexta1;
    }

    public void setSexta1(String Sexta1) {
        this.Sexta1 = Sexta1;
    }

    public String getSexta2() {
        return Sexta2;
    }

    public void setSexta2(String Sexta2) {
        this.Sexta2 = Sexta2;
    }

    public String getSexta3() {
        return Sexta3;
    }

    public void setSexta3(String Sexta3) {
        this.Sexta3 = Sexta3;
    }

    public String getSexta4() {
        return Sexta4;
    }

    public void setSexta4(String Sexta4) {
        this.Sexta4 = Sexta4;
    }

    public String getSexta5() {
        return Sexta5;
    }

    public void setSexta5(String Sexta5) {
        this.Sexta5 = Sexta5;
    }

    public String getSexta6() {
        return Sexta6;
    }

    public void setSexta6(String Sexta6) {
        this.Sexta6 = Sexta6;
    }

    public String getSexta7() {
        return Sexta7;
    }

    public void setSexta7(String Sexta7) {
        this.Sexta7 = Sexta7;
    }

    public String getSexta8() {
        return Sexta8;
    }

    public void setSexta8(String Sexta8) {
        this.Sexta8 = Sexta8;
    }

    public String getSabado1() {
        return Sabado1;
    }

    public void setSabado1(String Sabado1) {
        this.Sabado1 = Sabado1;
    }

    public String getSabado2() {
        return Sabado2;
    }

    public void setSabado2(String Sabado2) {
        this.Sabado2 = Sabado2;
    }

    public String getSabado3() {
        return Sabado3;
    }

    public void setSabado3(String Sabado3) {
        this.Sabado3 = Sabado3;
    }

    public String getSabado4() {
        return Sabado4;
    }

    public void setSabado4(String Sabado4) {
        this.Sabado4 = Sabado4;
    }

    public String getSabado5() {
        return Sabado5;
    }

    public void setSabado5(String Sabado5) {
        this.Sabado5 = Sabado5;
    }

    public String getSabado6() {
        return Sabado6;
    }

    public void setSabado6(String Sabado6) {
        this.Sabado6 = Sabado6;
    }

    public String getSabado7() {
        return Sabado7;
    }

    public void setSabado7(String Sabado7) {
        this.Sabado7 = Sabado7;
    }

    public String getSabado8() {
        return Sabado8;
    }

    public void setSabado8(String Sabado8) {
        this.Sabado8 = Sabado8;
    }

    public String getDomingo1() {
        return Domingo1;
    }

    public void setDomingo1(String Domingo1) {
        this.Domingo1 = Domingo1;
    }

    public String getDomingo2() {
        return Domingo2;
    }

    public void setDomingo2(String Domingo2) {
        this.Domingo2 = Domingo2;
    }

    public String getDomingo3() {
        return Domingo3;
    }

    public void setDomingo3(String Domingo3) {
        this.Domingo3 = Domingo3;
    }

    public String getDomingo4() {
        return Domingo4;
    }

    public void setDomingo4(String Domingo4) {
        this.Domingo4 = Domingo4;
    }

    public String getDomingo5() {
        return Domingo5;
    }

    public void setDomingo5(String Domingo5) {
        this.Domingo5 = Domingo5;
    }

    public String getDomingo6() {
        return Domingo6;
    }

    public void setDomingo6(String Domingo6) {
        this.Domingo6 = Domingo6;
    }

    public String getDomingo7() {
        return Domingo7;
    }

    public void setDomingo7(String Domingo7) {
        this.Domingo7 = Domingo7;
    }

    public String getDomingo8() {
        return Domingo8;
    }

    public void setDomingo8(String Domingo8) {
        this.Domingo8 = Domingo8;
    }

    public cronogramaEstudos() {
    }
}
